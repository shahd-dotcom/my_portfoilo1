export default function Footer() {
  return (
    <footer className="py-8 bg-primary text-primary-foreground">
      <div className="container px-4 md:px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-2xl font-heading font-bold">
          Shahd Milhem
        </div>
        <p className="text-sm text-primary-foreground/60">
          © {new Date().getFullYear()} Shahd Milhem. All rights reserved.
        </p>
        <div className="flex gap-6">
          <a href="https://www.facebook.com/share/1A2R4JKSeZ/?mibextid=wwXIfr" target="_blank" rel="noopener noreferrer" className="text-sm text-primary-foreground/60 hover:text-white transition-colors">Facebook</a>
        </div>
      </div>
    </footer>
  );
}
