import { motion } from "framer-motion";
import { ExternalLink, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

import photoProject from "@assets/generated_images/professional_photography_workspace_with_camera.png";
import marketingProject from "@assets/generated_images/digital_marketing_concept_with_analytics.png";
import contentProject from "@assets/generated_images/content_creation_and_video_editing_setup.png";

const projects = [
  {
    title: "Photography & Product Shooting",
    description: "Captured and edited professional product photos for online marketing campaigns. Focused on highlighting product features through lighting and composition.",
    image: photoProject,
    tags: ["Photography", "Editing", "Lightroom"],
    link: "https://drive.google.com/file/d/1LuAdo8d81YndOaS02tlQ9uOGTDong8zH/view?usp=drivesdk"
  },
  {
    title: "Marketing Strategy & Social Media",
    description: "Managed and optimized online campaigns across multiple platforms, increasing engagement and brand visibility.",
    image: marketingProject,
    tags: ["Marketing", "Analytics", "Strategy"],
    link: "https://drive.google.com/file/d/1caDhIxrCG2dBovBI0TQSdpOVg49gsOfw/view?usp=drivesdk"
  },
  {
    title: "Content Creation",
    description: "Edited photos and videos to meet strict brand standards, creating cohesive visual identities for marketing goals.",
    image: contentProject,
    tags: ["Video Editing", "Content", "Branding"],
    link: "https://drive.google.com/file/d/1XOIY-0nsyF9UqbiPcyNzkeY5GXBcu3rq/view?usp=drivesdk"
  }
];

export default function Projects() {
  return (
    <section id="projects" className="py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-5xl font-heading font-bold mb-4">Featured Work</h2>
            <p className="text-muted-foreground text-lg">A selection of my recent projects and collaborations.</p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="overflow-hidden border-none shadow-md hover:shadow-xl transition-all duration-300 group h-full flex flex-col bg-background">
                <div className="relative aspect-video overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <a href={project.link} target="_blank" rel="noopener noreferrer">
                      <Button variant="secondary" size="sm" className="rounded-full gap-2">
                        View Project <ArrowRight className="w-4 h-4" />
                      </Button>
                    </a>
                  </div>
                </div>
                <CardContent className="p-6 flex-grow flex flex-col">
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.map(tag => (
                      <Badge key={tag} variant="secondary" className="font-normal text-xs">{tag}</Badge>
                    ))}
                  </div>
                  <h3 className="font-heading text-xl font-bold mb-2 group-hover:text-primary/80 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-grow">
                    {project.description}
                  </p>
                  <a href={project.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-sm font-medium text-primary hover:underline mt-auto">
                    View Details <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
