import { motion } from "framer-motion";
import { Code, Palette, Kanban, MessageCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const skills = [
  {
    category: "Photography",
    icon: <Palette className="w-8 h-8" />,
    items: ["Product Shooting", "Lighting", "Composition"],
    level: 90
  },
  {
    category: "Product Shooting",
    icon: <Code className="w-8 h-8" />,
    items: ["Studio Setup", "Styling", "Camera Settings"],
    level: 85
  },
  {
    category: "Editing",
    icon: <Kanban className="w-8 h-8" />,
    items: ["Lightroom", "Photoshop", "Color Correction"],
    level: 80
  },
  {
    category: "Online Marketing",
    icon: <MessageCircle className="w-8 h-8" />,
    items: ["Social Media", "Campaigns", "Analytics"],
    level: 70
  }
];

export default function Skills() {
  return (
    <section id="skills" className="py-24 bg-background">
      <div className="container px-4 md:px-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-heading font-bold mb-4">My Expertise</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A blend of creative artistry and technical business knowledge.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="h-full border-none shadow-lg hover:shadow-xl transition-shadow bg-card/50 backdrop-blur-sm">
                <CardContent className="p-8 flex flex-col items-center text-center h-full">
                  <div className="p-4 rounded-full bg-secondary text-primary mb-6">
                    {skill.icon}
                  </div>
                  <h3 className="font-heading text-xl font-bold mb-4">{skill.category}</h3>
                  <ul className="space-y-2 text-muted-foreground mb-6 flex-grow">
                    {skill.items.map((item) => (
                      <li key={item} className="text-sm">{item}</li>
                    ))}
                  </ul>
                  {/* Progress bar visual */}
                  <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden mt-auto">
                    <motion.div 
                      className="h-full bg-primary"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      transition={{ duration: 1, delay: 0.5 }}
                    />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
