import { motion } from "framer-motion";

export default function About() {
  return (
    <section id="about" className="py-24 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-sm uppercase tracking-widest text-primary/60 font-semibold mb-2">About Me</h2>
            <h3 className="text-3xl md:text-4xl font-heading font-bold mb-6 text-balance">
              Capturing moments and creating digital experiences.
            </h3>
            <div className="space-y-4 text-muted-foreground text-lg leading-relaxed">
              <p>
                I am a Business Technology student with a diverse skillset that bridges the gap between creativity and strategy.
              </p>
              <p>
                My journey includes practical training at Grow Up Agency, where I honed my skills in product photography—mastering lighting, composition, and post-processing to create compelling visual narratives for online brands.
              </p>
              <p>
                Beyond the lens, I am passionate about digital marketing and content creation, always looking for new ways to help businesses tell their stories effectively.
              </p>
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-heading text-xl font-bold mb-1">Education</h4>
                <p className="text-muted-foreground">Business Technology Student</p>
              </div>
              <div>
                <h4 className="font-heading text-xl font-bold mb-1">Experience</h4>
                <p className="text-muted-foreground">Grow Up Agency (Training)</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
